import {
  Body,
  Button,
  Container,
  Head,
  Heading,
  Hr,
  Html,
  Img,
  Link,
  Preview,
  Section,
  Text,
} from "@react-email/components";

export type WelcomeProps = {
  firstName: string | null;
  verifyUrl: string;
  siteUrl: string;
  manageUrl: string;
  marketingOptIn: boolean;
  heroUrl: string;
};

const c = {
  ivory: "#FAF8F3",
  cream: "#F4EBDD",
  sage: "#A9BEA3",
  forest: "#243C32",
  peach: "#F4C6AD",
  charcoal: "#252525",
  muted: "#5B665F",
};

export default function Welcome({ firstName, verifyUrl, siteUrl, manageUrl, marketingOptIn, heroUrl }: WelcomeProps) {
  return (
    <Html lang="en">
      <Head />
      <Preview>You&apos;re one step closer to a smarter way to care for your best friend.</Preview>
      <Body style={{ backgroundColor: c.cream, margin: 0, padding: "24px 12px", fontFamily: "Helvetica, Arial, sans-serif", color: c.charcoal }}>
        <Container style={{ maxWidth: 560, margin: "0 auto", backgroundColor: c.ivory, borderRadius: 20, overflow: "hidden" }}>
          <Section style={{ backgroundColor: c.sage, padding: "22px 28px" }}>
            <Text style={{ margin: 0, fontSize: 24, fontWeight: 700, color: c.forest, letterSpacing: "-0.01em" }}>
              🐾 PetWhoop
            </Text>
          </Section>

          <Img src={heroUrl} alt="Concept illustration of the PetWhoop feeder and a happy dog" width="560" style={{ display: "block", width: "100%", height: "auto" }} />

          <Section style={{ padding: "28px 28px 8px" }}>
            <Heading as="h1" style={{ margin: "0 0 14px", fontSize: 28, lineHeight: "1.2", color: c.forest }}>
              Welcome to the PetWhoop Family! 🐾
            </Heading>
            <Text style={p}>{firstName ? `Hi ${firstName},` : "Hello,"}</Text>
            <Text style={p}>We&apos;re so excited to have you here.</Text>
            <Text style={p}>
              At PetWhoop, we believe that every pet deserves care as unique as they are. That&apos;s why we&apos;re developing
              a smarter approach to feeding, one that connects daily activity, thoughtful nutrition, and automated
              convenience.
            </Text>
            <Text style={p}>
              Our mission is simple: to help pet parents care for their companions with greater confidence and ease. And now,
              you&apos;re part of our journey.
            </Text>
          </Section>

          <Section style={{ padding: "8px 28px 0" }}>
            <Section style={{ backgroundColor: c.cream, borderRadius: 14, padding: "18px 20px" }}>
              <Text style={{ ...p, margin: "0 0 12px", fontWeight: 700, color: c.forest }}>One quick step: confirm your email address</Text>
              <Text style={{ ...p, margin: "0 0 14px" }}>
                This makes sure the address is really yours. The link works for 7 days.
              </Text>
              <Button href={verifyUrl} style={{ backgroundColor: c.forest, color: c.ivory, fontWeight: 700, fontSize: 16, padding: "13px 22px", borderRadius: 12, textDecoration: "none" }}>
                Confirm my email
              </Button>
            </Section>
          </Section>

          <Section style={{ padding: "20px 28px 4px" }}>
            {marketingOptIn ? (
              <Text style={p}>
                As a member of our early-access community who opted in to updates, you&apos;ll be among the first to hear about
                our progress, product milestones, and future launch plans. We&apos;re building something special, and we can&apos;t
                wait to share it with you.
              </Text>
            ) : (
              <Text style={p}>
                You haven&apos;t opted in to product updates, so we won&apos;t send you newsletters or promotional emails. You can
                change your mind at any time using the link at the bottom of this email.
              </Text>
            )}
            <Text style={{ ...p, fontWeight: 700, color: c.forest }}>Smarter Feeding. Happier Tails.</Text>
            <Text style={p}>
              With love,
              <br />
              <strong>The PetWhoop Team</strong>
            </Text>
            <Button href={siteUrl} style={{ backgroundColor: c.peach, color: c.forest, fontWeight: 700, fontSize: 16, padding: "13px 22px", borderRadius: 12, textDecoration: "none" }}>
              Explore PetWhoop
            </Button>
          </Section>

          <Hr style={{ borderColor: c.cream, margin: "26px 28px 0" }} />
          <Section style={{ padding: "16px 28px 28px" }}>
            <Text style={{ margin: "0 0 8px", fontSize: 12, lineHeight: "1.6", color: c.muted }}>
              PetWhoop is in development, with a working university senior-design prototype. Images are concept illustrations,
              not photographs of a finished product, and nothing here is a promise of availability or a date.
            </Text>
            <Text style={{ margin: 0, fontSize: 12, lineHeight: "1.6", color: c.muted }}>
              You&apos;re receiving this because someone signed up for the PetWhoop waitlist with this email address. If that
              wasn&apos;t you, ignore this message.{" "}
              <Link href={manageUrl} style={{ color: c.forest }}>
                Unsubscribe or delete my data
              </Link>
            </Text>
          </Section>
        </Container>
      </Body>
    </Html>
  );
}

const p = { margin: "0 0 14px", fontSize: 16, lineHeight: "1.6", color: c.charcoal } as const;
