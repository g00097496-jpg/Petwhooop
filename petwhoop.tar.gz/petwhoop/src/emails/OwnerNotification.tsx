import { Body, Button, Container, Head, Heading, Html, Preview, Section, Text } from "@react-email/components";

export type OwnerNotificationProps = {
  firstName: string | null;
  email: string;
  signedUpAt: string; // ISO timestamp
  marketingOptIn: boolean;
  adminUrl: string;
};

const c = { ivory: "#FAF8F3", cream: "#F4EBDD", sage: "#A9BEA3", forest: "#243C32", charcoal: "#252525", muted: "#5B665F" };

export default function OwnerNotification({ firstName, email, signedUpAt, marketingOptIn, adminUrl }: OwnerNotificationProps) {
  const when = new Date(signedUpAt);
  const whenText = `${when.toUTCString()}`;
  return (
    <Html lang="en">
      <Head />
      <Preview>{`${email} just joined the PetWhoop waitlist.`}</Preview>
      <Body style={{ backgroundColor: c.cream, margin: 0, padding: "24px 12px", fontFamily: "Helvetica, Arial, sans-serif", color: c.charcoal }}>
        <Container style={{ maxWidth: 520, margin: "0 auto", backgroundColor: c.ivory, borderRadius: 16, padding: "28px" }}>
          <Heading as="h1" style={{ margin: "0 0 18px", fontSize: 24, color: c.forest }}>
            🐾 New PetWhoop waitlist signup
          </Heading>
          <Section style={{ backgroundColor: c.cream, borderRadius: 12, padding: "14px 18px", marginBottom: 18 }}>
            <Text style={row}>
              <strong>Name:</strong> {firstName ?? "Not provided"}
            </Text>
            <Text style={row}>
              <strong>Email:</strong> {email}
            </Text>
            <Text style={row}>
              <strong>Signed up:</strong> {whenText}
            </Text>
            <Text style={{ ...row, marginBottom: 0 }}>
              <strong>Marketing opt-in:</strong> {marketingOptIn ? "Yes, ticked the box" : "No"}
            </Text>
          </Section>
          <Button href={adminUrl} style={{ backgroundColor: c.forest, color: c.ivory, fontWeight: 700, fontSize: 15, padding: "12px 20px", borderRadius: 10, textDecoration: "none" }}>
            Open the admin dashboard
          </Button>
          <Text style={{ margin: "18px 0 0", fontSize: 12, color: c.muted, lineHeight: "1.6" }}>
            The dashboard needs your administrator login. This email contains no access links or tokens.
          </Text>
        </Container>
      </Body>
    </Html>
  );
}

const row = { margin: "0 0 8px", fontSize: 15, lineHeight: "1.5" } as const;
