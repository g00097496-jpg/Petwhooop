"use client";
import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { Paw } from "./Illustrations";

declare global {
  interface Window {
    turnstile?: { render: (el: HTMLElement, o: Record<string, unknown>) => string; reset: (id?: string) => void };
  }
}

const CONSENT =
  "Yes, I'd like to receive PetWhoop news, product updates and launch announcements by email. I can unsubscribe at any time.";
const SITE_KEY = process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY;

export function WaitlistForm() {
  const reduce = useReducedMotion();
  const [status, setStatus] = useState<"idle" | "sending" | "done" | "error">("idle");
  const [error, setError] = useState("");
  const [token, setToken] = useState("");
  const submitted = useRef(false);
  const tsRef = useRef<HTMLDivElement>(null);
  const widgetId = useRef<string | undefined>(undefined);

  useEffect(() => {
    if (!SITE_KEY) return;
    const mount = () => {
      if (tsRef.current && window.turnstile && widgetId.current === undefined) {
        widgetId.current = window.turnstile.render(tsRef.current, {
          sitekey: SITE_KEY,
          callback: (t: string) => setToken(t),
          "expired-callback": () => setToken(""),
          theme: "light",
        });
      }
    };
    if (window.turnstile) return mount();
    const s = document.createElement("script");
    s.src = "https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit";
    s.async = true;
    s.onload = mount;
    document.head.appendChild(s);
  }, []);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (submitted.current) return; // blocks accidental double submits
    const form = new FormData(e.currentTarget);
    submitted.current = true;
    setStatus("sending");
    setError("");
    try {
      const res = await fetch("/api/waitlist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: form.get("email"),
          firstName: form.get("firstName"),
          marketingConsent: form.get("marketing") === "on",
          website: form.get("website"),
          turnstileToken: token,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.ok) return setStatus("done");
      setError(data.message || "Something went wrong. Please try again.");
    } catch {
      setError("We couldn't reach the server. Please check your connection and try again.");
    }
    submitted.current = false;
    setStatus("error");
    if (SITE_KEY && window.turnstile) { window.turnstile.reset(widgetId.current); setToken(""); }
  }

  if (status === "done") {
    return (
      <div role="status" className="relative overflow-hidden rounded-4xl bg-ivory p-10 text-center shadow-lift">
        {!reduce &&
          [0, 1, 2, 3, 4].map((i) => (
            <motion.span key={i} className="absolute bottom-6" style={{ left: `${12 + i * 19}%` }} initial={{ y: 0, opacity: 0 }} animate={{ y: -160, opacity: [0, 1, 0] }} transition={{ duration: 2.4, delay: i * 0.25, repeat: Infinity }}>
              <Paw className="h-7 w-7" fill={i % 2 ? "#F4C6AD" : "#A9BEA3"} />
            </motion.span>
          ))}
        <p className="relative font-display text-2xl leading-snug text-forest">You&apos;re officially part of the pack! 🐾</p>
        <p className="relative mt-3 text-charcoal/80">Keep an eye on your inbox — something exciting is on its way.</p>
      </div>
    );
  }

  const busy = status === "sending";
  const field = "w-full rounded-2xl border border-forest/15 bg-ivory px-5 py-3.5 text-base text-charcoal placeholder:text-charcoal/40 focus:border-sage-deep";
  return (
    <form onSubmit={onSubmit} className="rounded-4xl bg-ivory p-8 text-left shadow-lift md:p-10" noValidate={false}>
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="email" className="mb-1.5 block text-sm font-semibold text-forest">Email address</label>
          <input id="email" name="email" type="email" required autoComplete="email" maxLength={254} placeholder="you@example.com" className={field} />
        </div>
        <div>
          <label htmlFor="firstName" className="mb-1.5 block text-sm font-semibold text-forest">First name <span className="font-normal text-charcoal/50">(optional)</span></label>
          <input id="firstName" name="firstName" type="text" autoComplete="given-name" maxLength={60} placeholder="Your first name" className={field} />
        </div>
      </div>
      {/* honeypot */}
      <div aria-hidden className="absolute left-[-9999px] h-0 w-0 overflow-hidden">
        <label>Website<input name="website" type="text" tabIndex={-1} autoComplete="off" /></label>
      </div>
      <label className="mt-5 flex cursor-pointer items-start gap-3 text-sm leading-relaxed text-charcoal/80">
        <input type="checkbox" name="marketing" className="mt-1 h-5 w-5 shrink-0 accent-[#4F6D4B]" />
        <span>{CONSENT}</span>
      </label>
      {SITE_KEY && <div ref={tsRef} className="mt-5" />}
      <button type="submit" disabled={busy || (Boolean(SITE_KEY) && !token)} className="btn btn-primary mt-6 w-full disabled:cursor-not-allowed disabled:opacity-60">
        {busy ? "Joining…" : "Join the Pack"}
      </button>
      <AnimatePresence>
        {status === "error" && (
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} role="alert" className="mt-4 text-sm text-peach-deep">{error}</motion.p>
        )}
      </AnimatePresence>
      <p className="mt-5 text-xs leading-relaxed text-charcoal/55">
        We use your details only to manage the PetWhoop waitlist and email you about it. Joining the waitlist does not sign you up for marketing unless you tick the box. See our{" "}
        <a href="/privacy" className="underline">Privacy Policy</a>. You can unsubscribe or ask us to delete your data at any time.
      </p>
    </form>
  );
}
