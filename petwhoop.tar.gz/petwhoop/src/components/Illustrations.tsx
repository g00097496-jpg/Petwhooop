// Hand-built SVG concept art. These are illustrations, not product photos or final renders.
export function Paw({ className = "", fill = "#A9BEA3" }: { className?: string; fill?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden="true" fill={fill}>
      <ellipse cx="32" cy="42" rx="14" ry="11" />
      <ellipse cx="14" cy="28" rx="6" ry="8" transform="rotate(-20 14 28)" />
      <ellipse cx="26" cy="17" rx="6" ry="8.5" transform="rotate(-6 26 17)" />
      <ellipse cx="40" cy="17" rx="6" ry="8.5" transform="rotate(6 40 17)" />
      <ellipse cx="51" cy="28" rx="6" ry="8" transform="rotate(20 51 28)" />
    </svg>
  );
}

export function DogScene({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 520 520" className={className} role="img" aria-label="Concept illustration: a happy dog wearing a collar beside a smart feeder">
      <defs>
        <radialGradient id="glow" cx="50%" cy="45%" r="60%">
          <stop offset="0" stopColor="#F4C6AD" stopOpacity=".55" />
          <stop offset="1" stopColor="#F4EBDD" stopOpacity="0" />
        </radialGradient>
      </defs>
      <circle cx="260" cy="250" r="240" fill="url(#glow)" />
      <ellipse cx="260" cy="468" rx="200" ry="20" fill="#243C32" opacity=".08" />
      {/* feeder */}
      <g transform="translate(300 170)">
        <rect x="0" y="0" width="150" height="270" rx="44" fill="#FAF8F3" stroke="#243C32" strokeWidth="3" />
        <rect x="18" y="22" width="114" height="120" rx="30" fill="#F4EBDD" />
        <circle cx="75" cy="82" r="28" fill="#A9BEA3" />
        <circle cx="75" cy="82" r="10" fill="#FAF8F3" />
        <rect x="26" y="176" width="98" height="14" rx="7" fill="#243C32" opacity=".85" />
        <path d="M18 270 q57 -64 114 0z" fill="#243C32" />
        <ellipse cx="75" cy="264" rx="48" ry="8" fill="#C9744A" opacity=".85" />
      </g>
      {/* dog */}
      <g transform="translate(40 150)">
        <path d="M60 290 q-8 -120 70 -150 q96 -30 130 40 q16 40 -6 110z" fill="#E8B98C" />
        <ellipse cx="150" cy="120" rx="80" ry="72" fill="#E8B98C" />
        <path d="M82 70 q-48 -6 -52 60 q4 34 36 20 q14 -34 16 -80z" fill="#C98F5E" />
        <path d="M214 66 q50 -4 54 62 q-4 34 -36 20 q-14 -36 -18 -82z" fill="#C98F5E" />
        <ellipse cx="150" cy="150" rx="46" ry="34" fill="#FAF8F3" />
        <ellipse cx="150" cy="134" rx="14" ry="10" fill="#252525" />
        <circle cx="118" cy="104" r="8" fill="#252525" /><circle cx="182" cy="104" r="8" fill="#252525" />
        <circle cx="120" cy="101" r="2.6" fill="#fff" /><circle cx="184" cy="101" r="2.6" fill="#fff" />
        <path d="M130 160 q20 20 40 0" stroke="#252525" strokeWidth="3.5" fill="none" strokeLinecap="round" />
        <path d="M144 166 q6 22 14 0z" fill="#F4C6AD" />
        {/* collar */}
        <path d="M84 188 q66 40 132 0 l-4 20 q-62 34 -124 0z" fill="#243C32" />
        <rect x="138" y="206" width="26" height="26" rx="8" fill="#A9BEA3" stroke="#FAF8F3" strokeWidth="3" />
        <circle cx="151" cy="219" r="4" fill="#FAF8F3" />
      </g>
    </svg>
  );
}

export function FeederArt({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 240 300" className={className} role="img" aria-label="Concept illustration of a smart feeder">
      <ellipse cx="120" cy="286" rx="90" ry="9" fill="#243C32" opacity=".1" />
      <rect x="40" y="14" width="160" height="250" rx="48" fill="#FAF8F3" stroke="#243C32" strokeWidth="3" />
      <rect x="58" y="34" width="124" height="110" rx="32" fill="#F4EBDD" />
      <circle cx="120" cy="88" r="28" fill="#A9BEA3" /><circle cx="120" cy="88" r="10" fill="#FAF8F3" />
      <rect x="68" y="168" width="104" height="12" rx="6" fill="#243C32" opacity=".85" />
      <path d="M58 264 q62 -62 124 0z" fill="#243C32" />
    </svg>
  );
}

export function CollarArt({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 240 300" className={className} role="img" aria-label="Concept illustration of a smart collar">
      <ellipse cx="120" cy="286" rx="90" ry="9" fill="#243C32" opacity=".1" />
      <ellipse cx="120" cy="150" rx="86" ry="104" fill="none" stroke="#243C32" strokeWidth="26" />
      <ellipse cx="120" cy="150" rx="86" ry="104" fill="none" stroke="#A9BEA3" strokeWidth="6" strokeDasharray="2 14" strokeLinecap="round" />
      <rect x="92" y="232" width="56" height="56" rx="18" fill="#FAF8F3" stroke="#243C32" strokeWidth="3" />
      <circle cx="120" cy="260" r="9" fill="#F4C6AD" />
    </svg>
  );
}
