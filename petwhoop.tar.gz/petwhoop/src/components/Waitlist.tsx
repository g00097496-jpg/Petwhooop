import { Reveal } from "./Reveal";
import { WaitlistForm } from "./WaitlistForm";

export function Waitlist() {
  return (
    <section id="waitlist" className="scroll-mt-16 bg-gradient-to-b from-cream to-peach/30">
      <div className="mx-auto max-w-2xl px-6 py-24 text-center md:py-32">
        <Reveal>
          <span className="eyebrow">Early Access</span>
          <h2 className="text-4xl leading-tight text-forest md:text-5xl">Something Wonderful Is Coming.</h2>
          <p className="mb-10 mt-5 text-lg leading-relaxed text-charcoal/75">
            Be among the first to discover PetWhoop. Join our early-access community for launch news, behind-the-scenes updates, and the opportunity to hear about availability first.
          </p>
          <WaitlistForm />
        </Reveal>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="bg-forest px-6 py-12 text-center text-sm text-ivory/70">
      <p className="font-display text-xl text-ivory">PetWhoop</p>
      <p className="mt-1">They Move. We Nourish.</p>
      <p className="mt-5"><a href="/privacy" className="underline">Privacy Policy</a></p>
      <p className="mt-5 text-xs text-ivory/50">© {new Date().getFullYear()} PetWhoop. A concept in development — not yet available for purchase.</p>
    </footer>
  );
}
