"use client";
import { useState } from "react";
import { Paw } from "./Illustrations";

const links = [
  { href: "#how", label: "How It Works" },
  { href: "#why", label: "Why PetWhoop" },
  { href: "#vision", label: "Our Vision" },
];

export function Logo() {
  return (
    <a href="#top" className="flex items-center gap-2 font-display text-2xl font-semibold text-forest" aria-label="PetWhoop home">
      <Paw className="h-6 w-6" fill="#4F6D4B" /> PetWhoop
    </a>
  );
}

export function Nav() {
  const [open, setOpen] = useState(false);
  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-forest/5 bg-ivory/75 backdrop-blur-lg">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-6 py-3.5" aria-label="Primary">
        <Logo />
        <ul className="hidden items-center gap-8 text-[15px] md:flex">
          {links.map((l) => (
            <li key={l.href}><a href={l.href} className="text-forest/80 transition hover:text-forest">{l.label}</a></li>
          ))}
          <li><a href="#waitlist" className="btn btn-primary !py-2.5">Join Waitlist</a></li>
        </ul>
        <button
          className="flex h-11 w-11 items-center justify-center rounded-full text-forest md:hidden"
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
          aria-controls="mobile-menu"
          onClick={() => setOpen(!open)}
        >
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            {open ? <path d="M6 6l12 12M18 6L6 18" /> : <path d="M4 7h16M4 12h16M4 17h16" />}
          </svg>
        </button>
      </nav>
      {open && (
        <ul id="mobile-menu" className="space-y-1 border-t border-forest/5 bg-ivory px-6 pb-6 pt-3 md:hidden">
          {links.map((l) => (
            <li key={l.href}><a href={l.href} onClick={() => setOpen(false)} className="block py-3 text-lg text-forest">{l.label}</a></li>
          ))}
          <li><a href="#waitlist" onClick={() => setOpen(false)} className="btn btn-primary mt-2 w-full">Join Waitlist</a></li>
        </ul>
      )}
    </header>
  );
}
