"use client";
import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { DogScene, Float, Paw } from "./Illustrations-client";

export function Hero() {
  const ref = useRef<HTMLElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], [0, reduce ? 0 : 80]);
  const rise = (d: number) =>
    reduce ? {} : { initial: { opacity: 0, y: 28 }, animate: { opacity: 1, y: 0 }, transition: { duration: 0.8, delay: d, ease: [0.22, 1, 0.36, 1] as const } };

  return (
    <section ref={ref} id="top" className="relative overflow-hidden bg-gradient-to-b from-cream via-ivory to-ivory pt-28">
      <div aria-hidden className="absolute -left-32 top-24 h-96 w-96 rounded-full bg-sage/30 blur-3xl" />
      <div aria-hidden className="absolute -right-24 top-10 h-[28rem] w-[28rem] rounded-full bg-peach/40 blur-3xl" />
      <Paw className="absolute left-[8%] top-[62%] hidden h-10 w-10 rotate-[-18deg] opacity-40 md:block" />
      <Paw className="absolute right-[44%] top-[22%] hidden h-7 w-7 rotate-[14deg] opacity-40 md:block" fill="#F4C6AD" />

      <div className="relative mx-auto grid max-w-6xl items-center gap-10 px-6 pb-24 md:grid-cols-2 md:pb-32">
        <div>
          <motion.span {...rise(0)} className="mb-6 inline-flex items-center gap-2 rounded-full border border-forest/15 bg-ivory/80 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.2em] text-forest">
            <span className="h-2 w-2 rounded-full bg-peach-deep" /> Coming Soon
          </motion.span>
          <motion.h1 {...rise(0.1)} className="text-5xl leading-[1.05] text-forest sm:text-6xl lg:text-7xl">
            Smarter Feeding.<br /><span className="italic text-sage-deep">Happier Tails.</span>
          </motion.h1>
          <motion.p {...rise(0.25)} className="mt-6 max-w-lg text-lg leading-relaxed text-charcoal/80">
            Meet PetWhoop — the next generation of personalized pet feeding. By connecting your pet&apos;s daily activity with intelligent portion control, we&apos;re reimagining how pets are nourished.
          </motion.p>
          <motion.div {...rise(0.4)} className="mt-9 flex flex-wrap gap-4">
            <a href="#waitlist" className="btn btn-primary">Get Early Access</a>
            <a href="#how" className="btn btn-ghost">Discover PetWhoop</a>
          </motion.div>
          <motion.p {...rise(0.5)} className="mt-6 text-sm text-charcoal/55">They Move. We Nourish.</motion.p>
        </div>
        <motion.div style={{ y }} className="relative mx-auto w-full max-w-md md:max-w-none">
          <Float><DogScene className="h-auto w-full" /></Float>
          <p className="mt-2 text-center text-xs text-charcoal/50">Concept render. Final product design may differ.</p>
        </motion.div>
      </div>
    </section>
  );
}
