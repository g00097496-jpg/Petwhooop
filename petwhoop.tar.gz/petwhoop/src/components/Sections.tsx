import { Reveal } from "./Reveal";
import { CollarArt, DogScene, FeederArt, Paw } from "./Illustrations";

function Heading({ eyebrow, title, children }: { eyebrow: string; title: string; children?: React.ReactNode }) {
  return (
    <Reveal className="mx-auto max-w-3xl text-center">
      <span className="eyebrow">{eyebrow}</span>
      <h2 className="text-4xl leading-tight text-forest md:text-5xl">{title}</h2>
      {children && <p className="mt-5 text-lg leading-relaxed text-charcoal/75">{children}</p>}
    </Reveal>
  );
}

const problems = [
  { t: "One-Size-Fits-All Portions", d: "Fixed feeding amounts may not reflect what each pet actually needs.", bg: "bg-cream", c: "#A9BEA3" },
  { t: "Changing Activity Levels", d: "Daily movement can vary significantly from one day to the next.", bg: "bg-peach/30", c: "#F4C6AD" },
  { t: "Busy Pet Parents", d: "Owners want convenient, consistent feeding without unnecessary complexity.", bg: "bg-sage/25", c: "#4F6D4B" },
];

export function Problem() {
  return (
    <section className="section" aria-labelledby="problem">
      <Heading eyebrow="The Story" title="Every Pet Is Different. Why Isn't Their Feeding?">
        <span id="problem" className="sr-only">Problem</span>
        Traditional automatic feeders typically rely on predetermined schedules and portions, while pets&apos; activity levels and nutritional needs can vary.
      </Heading>
      <div className="mt-14 grid gap-6 md:grid-cols-3">
        {problems.map((p, i) => (
          <Reveal key={p.t} delay={i * 0.1}>
            <div className={`${p.bg} h-full rounded-4xl p-8 transition duration-500 hover:-translate-y-1 hover:shadow-lift`}>
              <Paw className="mb-6 h-10 w-10" fill={p.c} />
              <h3 className="text-2xl text-forest">{p.t}</h3>
              <p className="mt-3 leading-relaxed text-charcoal/75">{p.d}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

export function Ecosystem() {
  return (
    <section className="bg-cream/70">
      <div className="section">
        <Heading eyebrow="The PetWhoop Ecosystem" title="Two Smart Devices. One Happier Pet." />
        <div className="mt-16 grid gap-8 md:grid-cols-2">
          <Reveal>
            <article className="rounded-4xl bg-ivory p-8 shadow-soft md:p-10">
              <CollarArt className="mx-auto h-56 w-auto" />
              <h3 className="mt-6 text-3xl text-forest">PetWhoop Smart Collar</h3>
              <p className="mt-1 font-display text-lg italic text-sage-deep">&ldquo;Every adventure tells a story.&rdquo;</p>
              <p className="mt-4 leading-relaxed text-charcoal/75">Activity tracking provides information that can help guide personalized feeding, so the system can learn how active your pet has been.</p>
            </article>
          </Reveal>
          <Reveal delay={0.15}>
            <article className="rounded-4xl bg-ivory p-8 shadow-soft md:p-10">
              <FeederArt className="mx-auto h-56 w-auto" />
              <h3 className="mt-6 text-3xl text-forest">PetWhoop Smart Feeder</h3>
              <p className="mt-1 font-display text-lg italic text-sage-deep">&ldquo;Thoughtful nutrition, automatically delivered.&rdquo;</p>
              <p className="mt-4 leading-relaxed text-charcoal/75">The feeder uses nutritional calculations and measured dispensing to support more personalized portions.</p>
            </article>
          </Reveal>
        </div>
        <p className="mt-6 text-center text-xs text-charcoal/50">Illustrated concept renders. Final product design may differ.</p>
      </div>
    </section>
  );
}

const steps = [
  { n: "01", t: "Wear", d: "Your pet wears the lightweight smart collar." },
  { n: "02", t: "Understand", d: "PetWhoop uses activity and nutritional information to estimate feeding needs." },
  { n: "03", t: "Nourish", d: "The feeder dispenses a measured portion based on the system's feeding logic." },
];

export function HowItWorks() {
  return (
    <section id="how" className="section scroll-mt-16">
      <Heading eyebrow="How It Works" title="Smart Feeding Made Simple." />
      <div className="relative mt-16 grid gap-10 md:grid-cols-3">
        <div aria-hidden className="absolute left-[16%] right-[16%] top-8 hidden border-t-2 border-dashed border-sage md:block" />
        {steps.map((s, i) => (
          <Reveal key={s.n} delay={i * 0.18} className="relative text-center">
            <div className="relative mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-forest font-display text-xl text-ivory shadow-lift">{s.n}</div>
            <h3 className="mt-6 text-2xl text-forest">{s.t}</h3>
            <p className="mx-auto mt-3 max-w-xs leading-relaxed text-charcoal/75">{s.d}</p>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

const benefits = [
  { t: "Personalized Feeding", d: "Portions guided by the individual pet, not a one-size-fits-all setting.", c: "#A9BEA3" },
  { t: "Activity-Aware Nutrition", d: "Feeding logic that takes daily movement into account.", c: "#F4C6AD" },
  { t: "Automated Convenience", d: "Measured portions delivered automatically, so routine feeding takes less effort.", c: "#4F6D4B" },
  { t: "Thoughtful Pet Technology", d: "Engineering designed around everyday care and the bond with your pet.", c: "#C9744A" },
];

export function Why() {
  return (
    <section id="why" className="scroll-mt-16 bg-forest text-ivory">
      <div className="section">
        <Reveal className="mx-auto max-w-3xl text-center">
          <span className="eyebrow !text-sage">Why PetWhoop</span>
          <h2 className="text-4xl leading-tight md:text-5xl">Because They Deserve More Than Ordinary.</h2>
        </Reveal>
        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {benefits.map((b, i) => (
            <Reveal key={b.t} delay={i * 0.08}>
              <div className="h-full rounded-4xl bg-ivory/[0.06] p-7 ring-1 ring-ivory/10 transition duration-500 hover:-translate-y-1 hover:bg-ivory/10">
                <Paw className="mb-5 h-9 w-9" fill={b.c} />
                <h3 className="text-xl">{b.t}</h3>
                <p className="mt-2 text-sm leading-relaxed text-ivory/75">{b.d}</p>
              </div>
            </Reveal>
          ))}
        </div>
        <p className="mt-10 text-center text-xs text-ivory/55">PetWhoop is a pet-feeding concept. It does not diagnose, prevent, or treat any medical condition.</p>
      </div>
    </section>
  );
}

export function Vision() {
  return (
    <section id="vision" className="section scroll-mt-16">
      <div className="grid items-center gap-12 md:grid-cols-2">
        <Reveal>
          <span className="eyebrow">Our Vision</span>
          <h2 className="text-4xl leading-tight text-forest md:text-5xl">Built With Love. Designed With Purpose.</h2>
          <p className="mt-6 text-lg leading-relaxed text-charcoal/80">
            We believe that caring for our pets should be as thoughtful as the love they give us. PetWhoop started with one simple question: what if feeding could understand more about the pet behind the bowl?
          </p>
          <p className="mt-4 leading-relaxed text-charcoal/75">
            PetWhoop is an engineering innovation created to rethink the relationship between pet activity, nutrition, and everyday care. The concept began as a university senior-design engineering project and is being developed toward a future consumer product.
          </p>
          <div className="mt-8 rounded-3xl bg-cream p-6 text-sm leading-relaxed text-charcoal/75">
            <p className="font-semibold text-forest">Where we are today</p>
            <p className="mt-2"><strong>Built as a prototype:</strong> collar activity sensing, a wireless link to the feeder, and motor-driven measured dispensing.</p>
            <p className="mt-2"><strong>Planned, not yet demonstrated:</strong> pet identification, weight monitoring, a mobile app and personalization that learns over time.</p>
            <p className="mt-2">PetWhoop is not yet for sale and there is no launch date.</p>
          </div>
        </Reveal>
        <Reveal delay={0.15}>
          <div className="rounded-[2.5rem] bg-gradient-to-br from-peach/40 via-cream to-sage/30 p-6">
            <DogScene className="h-auto w-full" />
            <p className="mt-1 text-center text-xs text-charcoal/50">Concept illustration</p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
