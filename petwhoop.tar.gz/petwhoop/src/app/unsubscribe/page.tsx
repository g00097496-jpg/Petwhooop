import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { verifyManageToken } from "@/lib/tokens";
import { deleteById, unsubscribeById } from "@/lib/subscriber-actions";

export const metadata: Metadata = { title: "Manage your subscription", robots: { index: false } };
export const dynamic = "force-dynamic";

async function act(formData: FormData) {
  "use server";
  const id = verifyManageToken(String(formData.get("token") ?? ""));
  const action = String(formData.get("action") ?? "");
  if (!id) redirect("/unsubscribe?done=invalid");
  if (action === "delete") await deleteById(id);
  else await unsubscribeById(id);
  redirect(`/unsubscribe?done=${action === "delete" ? "deleted" : "unsubscribed"}`);
}

export default async function UnsubscribePage({ searchParams }: { searchParams: Promise<{ token?: string; done?: string }> }) {
  const { token, done } = await searchParams;
  const valid = Boolean(verifyManageToken(token));

  let body;
  if (done === "unsubscribed") body = <p>You're unsubscribed. We won't send you marketing emails.</p>;
  else if (done === "deleted") body = <p>Your details have been deleted. We keep only a one-way hash of your address so we never email you again.</p>;
  else if (!valid) body = <p>This link isn't valid. Please use the link from one of our emails.</p>;
  else
    body = (
      <form action={act} className="space-y-4">
        <input type="hidden" name="token" value={token} />
        <p>Choose what you'd like to do.</p>
        <div className="flex flex-col gap-3 sm:flex-row sm:justify-center">
          <button name="action" value="unsubscribe" className="rounded-full bg-forest px-6 py-3 text-ivory">Unsubscribe from emails</button>
          <button name="action" value="delete" className="rounded-full border border-forest px-6 py-3 text-forest">Delete my data</button>
        </div>
      </form>
    );

  return (
    <main className="mx-auto flex min-h-screen max-w-xl flex-col items-center justify-center px-6 text-center text-charcoal/80">
      <h1 className="mb-6 font-display text-4xl text-forest">Manage your subscription</h1>
      {body}
      <Link href="/" className="mt-8 text-sm underline">Back to PetWhoop</Link>
    </main>
  );
}
