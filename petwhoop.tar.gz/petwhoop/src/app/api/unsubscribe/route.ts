import { NextResponse } from "next/server";
import { verifyManageToken } from "@/lib/tokens";
import { unsubscribeById } from "@/lib/subscriber-actions";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// RFC 8058 one-click unsubscribe: mail clients POST here. Token is HMAC-signed, so no login is needed.
export async function POST(req: Request) {
  const token = new URL(req.url).searchParams.get("token");
  const id = verifyManageToken(token);
  if (!id) return NextResponse.json({ ok: false }, { status: 400 });
  await unsubscribeById(id);
  return NextResponse.json({ ok: true });
}
