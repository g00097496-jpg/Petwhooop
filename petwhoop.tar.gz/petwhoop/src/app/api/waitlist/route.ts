import { after, NextResponse } from "next/server";
import { clientIp, originAllowed } from "@/lib/site";
import { CONSENT_TEXT_VERSION, cleanFirstName, isValidEmail, normalizeEmail } from "@/lib/validate";
import { hashIp, newVerificationToken, sha256Hex } from "@/lib/tokens";
import { isRateLimited, verifyTurnstile } from "@/lib/security";
import { supabaseAdmin } from "@/lib/supabase-admin";
import { sendSignupEmails } from "@/lib/email";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// The same answer is returned for new and existing addresses so the form cannot be used
// to discover who is on the list.
const OK = { ok: true } as const;

function fail(message: string, status: number) {
  return NextResponse.json({ ok: false, message }, { status });
}

export async function POST(req: Request) {
  if (!originAllowed(req.headers.get("origin"))) return fail("Request not allowed.", 403);

  // Small bodies only.
  const raw = await req.text();
  if (raw.length > 4096) return fail("Request too large.", 413);
  let body: Record<string, unknown>;
  try {
    body = JSON.parse(raw);
  } catch {
    return fail("Invalid request.", 400);
  }

  // Honeypot: real people never see or fill this field. Pretend it worked.
  if (typeof body.website === "string" && body.website.trim() !== "") return NextResponse.json(OK);

  const ip = clientIp(req.headers);
  const production = process.env.NODE_ENV === "production";

  // Server must be fully configured before it accepts personal data.
  if (!process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
    return fail("Signup is not available yet. Please try again soon.", 503);
  }
  if (production && !process.env.TURNSTILE_SECRET_KEY) {
    return fail("Signup is not available yet. Please try again soon.", 503);
  }

  try {
    if (await isRateLimited(hashIp(ip))) {
      return fail("Too many attempts. Please wait a few minutes and try again.", 429);
    }

    if (process.env.TURNSTILE_SECRET_KEY) {
      const human = await verifyTurnstile(typeof body.turnstileToken === "string" ? body.turnstileToken : undefined, ip);
      if (!human) return fail("We couldn't confirm you're human. Please reload and try again.", 400);
    }

    const email = normalizeEmail(body.email);
    if (!isValidEmail(email)) return fail("Please enter a valid email address.", 400);

    const marketing = body.marketingConsent === true; // never defaulted to true
    const now = new Date().toISOString();
    const token = newVerificationToken();

    const { data, error } = await supabaseAdmin()
      .from("subscribers")
      .insert({
        email,
        first_name: cleanFirstName(body.firstName),
        marketing_consent: marketing,
        consent_timestamp: marketing ? now : null,
        consent_text_version: marketing ? CONSENT_TEXT_VERSION : null,
        consent_source: marketing ? "website_waitlist_form" : null,
        verification_token_hash: sha256Hex(token),
        verification_expires_at: new Date(Date.now() + 7 * 86_400_000).toISOString(),
        signup_ip_hash: hashIp(ip),
      })
      .select("id")
      .single();

    if (error) {
      // 23505 = unique violation: this address is already on the list. Treat as success, send nothing.
      if (error.code === "23505") return NextResponse.json(OK);
      console.error("waitlist insert failed", error.code, error.message);
      return fail("Something went wrong. Please try again.", 500);
    }

    // Emails go out after the response so the visitor isn't kept waiting. Failures are logged on the row.
    after(async () => {
      try {
        await sendSignupEmails(data.id as string);
      } catch (e) {
        console.error("signup emails failed", e);
      }
    });

    return NextResponse.json(OK);
  } catch (e) {
    console.error("waitlist error", e);
    return fail("Something went wrong. Please try again.", 500);
  }
}
