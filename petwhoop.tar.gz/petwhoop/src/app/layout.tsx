import type { Metadata, Viewport } from "next";
import "./globals.css";

const url = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";
const description =
  "PetWhoop is a coming-soon smart collar and feeder concept that connects your pet's daily activity with intelligent portion control. Join the early-access waitlist.";

export const metadata: Metadata = {
  metadataBase: new URL(url),
  title: { default: "PetWhoop — Smarter Feeding. Happier Tails.", template: "%s · PetWhoop" },
  description,
  openGraph: { title: "PetWhoop — Smarter Feeding. Happier Tails.", description, url, siteName: "PetWhoop", type: "website", images: [{ url: "/og.png", width: 1200, height: 630, alt: "PetWhoop concept illustration" }] },
  twitter: { card: "summary_large_image", title: "PetWhoop — Smarter Feeding. Happier Tails.", description, images: ["/og.png"] },
};
export const viewport: Viewport = { themeColor: "#FAF8F3", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600&family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;1,9..144,400&display=swap" rel="stylesheet" />
      </head>
      <body>{children}</body>
    </html>
  );
}
