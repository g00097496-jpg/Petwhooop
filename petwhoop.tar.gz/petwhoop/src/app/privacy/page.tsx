import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = { title: "Privacy Policy" };

export default function Privacy() {
  return (
    <main className="mx-auto max-w-2xl px-6 py-20 leading-relaxed text-charcoal/85">
      <Link href="/" className="text-sm underline">← Back to PetWhoop</Link>
      <h1 className="mt-6 text-4xl text-forest">Privacy Policy</h1>
      <p className="mt-3 rounded-2xl bg-peach/30 p-4 text-sm">
        <strong>DRAFT — requires legal review before launch.</strong> This text describes how the site is built to work. It has not been reviewed by a lawyer, and must be checked against UAE personal data protection law (including Federal Decree-Law No. 45 of 2021) and any other laws that apply to your visitors before real signups are collected. Replace the bracketed placeholders.
      </p>
      <h2 className="mt-10 text-2xl text-forest">Who we are</h2>
      <p className="mt-2">PetWhoop is an early-stage project run by [legal entity / team names], [address]. Contact: [privacy contact email].</p>
      <h2 className="mt-8 text-2xl text-forest">What we collect</h2>
      <p className="mt-2">Your email address, your first name (optional), whether you ticked the marketing box (with the time and wording version), your email confirmation status, and technical data needed to run the waitlist securely, such as a one-way hash of your IP address used for abuse prevention (kept for a short period).</p>
      <h2 className="mt-8 text-2xl text-forest">Why we use it</h2>
      <p className="mt-2">To manage the waitlist and send you the confirmation email. If you ticked the optional box, to send PetWhoop news and launch updates. We do not sell your data.</p>
      <h2 className="mt-8 text-2xl text-forest">Who processes it</h2>
      <p className="mt-2">Supabase (database), Resend (email delivery), Cloudflare Turnstile (bot protection) and Vercel (hosting). These providers may process data outside the UAE. [Confirm regions and transfer safeguards.]</p>
      <h2 className="mt-8 text-2xl text-forest">Your choices</h2>
      <p className="mt-2">Every email contains a link to unsubscribe or to delete your data. You can also write to [privacy contact email]. If you unsubscribe or delete your data, we keep only a one-way hash of your email address so we never email you again.</p>
      <h2 className="mt-8 text-2xl text-forest">Retention</h2>
      <p className="mt-2">[Decide and state how long waitlist data is kept, for example until launch plus a set period, or until you ask us to delete it.]</p>
      <p className="mt-10 text-sm text-charcoal/50">Last updated: [date]</p>
    </main>
  );
}
