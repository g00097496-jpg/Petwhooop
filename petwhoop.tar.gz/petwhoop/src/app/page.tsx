import { Nav } from "@/components/Nav";
import { Hero } from "@/components/Hero";
import { Ecosystem, HowItWorks, Problem, Vision, Why } from "@/components/Sections";
import { Footer, Waitlist } from "@/components/Waitlist";

export default function Home() {
  return (
    <>
      <Nav />
      <main>
        <Hero />
        <Problem />
        <Ecosystem />
        <HowItWorks />
        <Why />
        <Vision />
        <Waitlist />
      </main>
      <Footer />
    </>
  );
}
