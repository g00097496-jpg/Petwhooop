import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { requireAdmin, sessionClient } from "@/lib/supabase-server";
import { supabaseAdmin } from "@/lib/supabase-admin";
import { retryEmail } from "@/lib/email";
import { deleteById } from "@/lib/subscriber-actions";

export const metadata: Metadata = { title: "Admin", robots: { index: false, follow: false } };
export const dynamic = "force-dynamic";

async function guard() {
  const u = await requireAdmin();
  if (!u) throw new Error("Not authorized");
}
async function retry(fd: FormData) {
  "use server";
  await guard();
  const id = String(fd.get("id"));
  const kind = fd.get("kind") === "notification" ? "notification" : "welcome";
  await retryEmail(id, kind);
  revalidatePath("/admin");
}
async function remove(fd: FormData) {
  "use server";
  await guard();
  await deleteById(String(fd.get("id")));
  revalidatePath("/admin");
}
async function signOut() {
  "use server";
  await (await sessionClient()).auth.signOut();
  redirect("/admin/login");
}

type Row = {
  id: string; email: string; first_name: string | null; created_at: string; marketing_consent: boolean;
  email_verification_status: string; welcome_email_status: string; notification_status: string; unsubscribed_at: string | null;
};

export default async function Admin({ searchParams }: { searchParams: Promise<{ q?: string; f?: string }> }) {
  const user = await requireAdmin();
  if (!user) redirect("/admin/login");
  const { q = "", f = "all" } = await searchParams;

  const { data } = await supabaseAdmin().from("subscribers").select("*").order("created_at", { ascending: false }).limit(2000);
  const all = (data ?? []) as Row[];
  const rows = all.filter((r) => {
    if (q && !`${r.email} ${r.first_name ?? ""}`.toLowerCase().includes(q.toLowerCase())) return false;
    if (f === "marketing") return r.marketing_consent;
    if (f === "verified") return r.email_verification_status === "verified";
    if (f === "failed") return r.welcome_email_status === "failed" || r.notification_status === "failed";
    return true;
  });

  const day = (d: string) => d.slice(0, 10);
  const trend: { d: string; n: number }[] = [];
  for (let i = 13; i >= 0; i--) {
    const d = new Date(Date.now() - i * 86_400_000).toISOString().slice(0, 10);
    trend.push({ d, n: all.filter((r) => day(r.created_at) === d).length });
  }
  const max = Math.max(1, ...trend.map((t) => t.n));
  const stat = (label: string, v: number) => (
    <div className="rounded-2xl bg-cream p-4"><p className="text-xs uppercase tracking-wider text-charcoal/60">{label}</p><p className="font-display text-3xl text-forest">{v}</p></div>
  );

  return (
    <main className="mx-auto max-w-6xl px-6 py-10">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl text-forest">PetWhoop waitlist</h1>
        <form action={signOut}><button className="text-sm underline">Sign out</button></form>
      </div>
      <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-5">
        {stat("Total", all.length)}
        {stat("Verified", all.filter((r) => r.email_verification_status === "verified").length)}
        {stat("Marketing opt-in", all.filter((r) => r.marketing_consent).length)}
        {stat("Unsubscribed", all.filter((r) => r.unsubscribed_at).length)}
        {stat("Email failures", all.filter((r) => r.welcome_email_status === "failed" || r.notification_status === "failed").length)}
      </div>
      <div className="mt-6 flex h-24 items-end gap-1" role="img" aria-label="Signups per day, last 14 days">
        {trend.map((t) => (
          <div key={t.d} title={`${t.d}: ${t.n}`} className="flex-1 rounded-t bg-sage" style={{ height: `${(t.n / max) * 100}%`, minHeight: 3 }} />
        ))}
      </div>
      <p className="mt-1 text-xs text-charcoal/50">Signups per day, last 14 days</p>

      <form className="mt-6 flex flex-wrap gap-3" method="get">
        <input name="q" defaultValue={q} placeholder="Search email or name" className="rounded-xl border border-forest/20 px-4 py-2" />
        <select name="f" defaultValue={f} className="rounded-xl border border-forest/20 px-3 py-2">
          <option value="all">All</option><option value="marketing">Marketing opt-in</option><option value="verified">Verified</option><option value="failed">Email failed</option>
        </select>
        <button className="btn btn-primary !py-2">Filter</button>
        <a href="/admin/export" className="btn btn-ghost !py-2">Export CSV</a>
      </form>

      <div className="mt-6 overflow-x-auto">
        <table className="w-full min-w-[760px] text-left text-sm">
          <thead className="text-xs uppercase tracking-wider text-charcoal/60">
            <tr><th className="py-2">Email</th><th>Name</th><th>Joined</th><th>Marketing</th><th>Verified</th><th>Welcome</th><th>Owner mail</th><th /></tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-t border-forest/10 align-top">
                <td className="py-2 pr-3">{r.email}{r.unsubscribed_at && <span className="ml-2 text-xs text-peach-deep">unsubscribed</span>}</td>
                <td>{r.first_name ?? "—"}</td>
                <td>{new Date(r.created_at).toLocaleString("en-GB", { timeZone: "Asia/Dubai" })}</td>
                <td>{r.marketing_consent ? "Yes" : "No"}</td>
                <td>{r.email_verification_status}</td>
                <td>{r.welcome_email_status}{r.welcome_email_status === "failed" && (
                  <form action={retry} className="inline"><input type="hidden" name="id" value={r.id} /><input type="hidden" name="kind" value="welcome" /><button className="ml-2 underline">retry</button></form>)}</td>
                <td>{r.notification_status}{r.notification_status === "failed" && (
                  <form action={retry} className="inline"><input type="hidden" name="id" value={r.id} /><input type="hidden" name="kind" value="notification" /><button className="ml-2 underline">retry</button></form>)}</td>
                <td><form action={remove}><input type="hidden" name="id" value={r.id} /><button className="text-peach-deep underline">remove</button></form></td>
              </tr>
            ))}
          </tbody>
        </table>
        {rows.length === 0 && <p className="py-8 text-center text-charcoal/60">No subscribers match.</p>}
      </div>
    </main>
  );
}
