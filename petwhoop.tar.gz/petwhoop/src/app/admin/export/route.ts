import { requireAdmin } from "@/lib/supabase-server";
import { supabaseAdmin } from "@/lib/supabase-admin";

export const dynamic = "force-dynamic";

// Spreadsheet apps run formulas that start with = + - @, so neutralise them.
function cell(v: unknown): string {
  let s = v === null || v === undefined ? "" : String(v);
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
  return `"${s.replace(/"/g, '""')}"`;
}

export async function GET() {
  if (!(await requireAdmin())) return new Response("Forbidden", { status: 403 });
  const { data, error } = await supabaseAdmin()
    .from("subscribers")
    .select("email,first_name,created_at,marketing_consent,consent_timestamp,consent_text_version,email_verification_status,welcome_email_status,notification_status,unsubscribed_at")
    .order("created_at", { ascending: false });
  if (error) return new Response("Export failed", { status: 500 });
  const cols = ["email", "first_name", "created_at", "marketing_consent", "consent_timestamp", "consent_text_version", "email_verification_status", "welcome_email_status", "notification_status", "unsubscribed_at"];
  const csv = [cols.join(","), ...(data ?? []).map((r) => cols.map((c) => cell((r as Record<string, unknown>)[c])).join(","))].join("\r\n");
  return new Response(csv, {
    headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": 'attachment; filename="petwhoop-waitlist.csv"', "Cache-Control": "no-store" },
  });
}
