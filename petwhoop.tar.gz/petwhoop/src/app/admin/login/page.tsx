import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { sessionClient } from "@/lib/supabase-server";

export const metadata: Metadata = { title: "Admin sign in", robots: { index: false, follow: false } };
export const dynamic = "force-dynamic";

async function login(formData: FormData) {
  "use server";
  const supabase = await sessionClient();
  const { error } = await supabase.auth.signInWithPassword({
    email: String(formData.get("email") ?? ""),
    password: String(formData.get("password") ?? ""),
  });
  if (error) redirect("/admin/login?error=1");
  redirect("/admin");
}

export default async function Login({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const { error } = await searchParams;
  return (
    <main className="mx-auto flex min-h-screen max-w-sm flex-col justify-center px-6">
      <h1 className="text-3xl text-forest">Admin sign in</h1>
      <form action={login} className="mt-6 space-y-4">
        <input name="email" type="email" required autoComplete="email" placeholder="Email" className="w-full rounded-xl border border-forest/20 px-4 py-3" />
        <input name="password" type="password" required autoComplete="current-password" placeholder="Password" className="w-full rounded-xl border border-forest/20 px-4 py-3" />
        <button className="btn btn-primary w-full">Sign in</button>
        {error && <p role="alert" className="text-sm text-peach-deep">Sign-in failed.</p>}
      </form>
    </main>
  );
}
