import type { Metadata } from "next";
import Link from "next/link";
import { sha256Hex } from "@/lib/tokens";
import { supabaseAdmin } from "@/lib/supabase-admin";

export const metadata: Metadata = { title: "Confirm your email", robots: { index: false } };
export const dynamic = "force-dynamic";

async function verify(token: string | undefined): Promise<"ok" | "invalid" | "expired"> {
  if (!token || token.length < 20 || token.length > 200) return "invalid";
  const db = supabaseAdmin();
  const { data } = await db
    .from("subscribers")
    .select("id, verification_expires_at, email_verification_status")
    .eq("verification_token_hash", sha256Hex(token))
    .maybeSingle();
  if (!data) return "invalid";
  if (data.email_verification_status === "verified") return "ok";
  if (!data.verification_expires_at || new Date(data.verification_expires_at as string) < new Date()) return "expired";
  await db
    .from("subscribers")
    .update({ email_verification_status: "verified", verified_at: new Date().toISOString(), verification_token_hash: null })
    .eq("id", data.id);
  return "ok";
}

export default async function VerifyPage({ searchParams }: { searchParams: Promise<{ token?: string }> }) {
  const { token } = await searchParams;
  let result: "ok" | "invalid" | "expired" = "invalid";
  try {
    result = await verify(token);
  } catch {
    result = "invalid";
  }
  const copy = {
    ok: { h: "Email confirmed 🐾", p: "Thank you. You're all set on the PetWhoop waitlist." },
    expired: { h: "This link has expired", p: "Confirmation links last 7 days. Join the waitlist again from the homepage and we'll send a fresh one." },
    invalid: { h: "We couldn't use this link", p: "It may be mistyped or already used. You can join the waitlist again from the homepage." },
  }[result];
  return (
    <main className="mx-auto flex min-h-screen max-w-xl flex-col items-center justify-center px-6 text-center">
      <h1 className="font-display text-4xl text-forest">{copy.h}</h1>
      <p className="mt-4 text-charcoal/80">{copy.p}</p>
      <Link href="/" className="mt-8 rounded-full bg-forest px-6 py-3 text-ivory">Back to PetWhoop</Link>
    </main>
  );
}
