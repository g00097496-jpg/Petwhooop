import { createHash, createHmac, randomBytes, timingSafeEqual } from "node:crypto";

export function sha256Hex(input: string): string {
  return createHash("sha256").update(input, "utf8").digest("hex");
}

/** Random one-time token for email verification (the raw value is emailed; only its hash is stored). */
export function newVerificationToken(): string {
  return randomBytes(32).toString("hex");
}

function secret(): string {
  const s = process.env.TOKEN_SECRET;
  if (!s || s.length < 32) throw new Error("TOKEN_SECRET is missing or shorter than 32 characters");
  return s;
}

/** Signed "manage my subscription" token: `<subscriberId>.<hmac>`. Used by unsubscribe and delete links. */
export function manageToken(subscriberId: string): string {
  const sig = createHmac("sha256", secret()).update(`manage:${subscriberId}`).digest("hex");
  return `${subscriberId}.${sig}`;
}

/** Returns the subscriber id when the token is authentic, otherwise null. */
export function verifyManageToken(token: string | null | undefined): string | null {
  if (!token || token.length > 200) return null;
  const dot = token.indexOf(".");
  if (dot < 1) return null;
  const id = token.slice(0, dot);
  const sig = token.slice(dot + 1);
  if (!/^[0-9a-f-]{36}$/i.test(id)) return null;
  const expected = createHmac("sha256", secret()).update(`manage:${id}`).digest("hex");
  const a = Buffer.from(sig, "utf8");
  const b = Buffer.from(expected, "utf8");
  if (a.length !== b.length) return null;
  return timingSafeEqual(a, b) ? id : null;
}

/** Salted hash of an IP address, for rate limiting. The raw address is never stored. */
export function hashIp(ip: string): string {
  const salt = process.env.IP_HASH_SALT ?? "";
  return sha256Hex(`${salt}|${ip}`);
}

/** Hash used by the suppression list. */
export function emailHash(normalizedEmail: string): string {
  return sha256Hex(normalizedEmail);
}
