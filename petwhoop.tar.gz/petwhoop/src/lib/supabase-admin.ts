import "server-only";
import { createClient, type SupabaseClient } from "@supabase/supabase-js";

let cached: SupabaseClient | null = null;

/**
 * Service-role client. Bypasses Row Level Security, so it must only be used in server code
 * (route handlers, server components, server actions). The `server-only` import makes the
 * build fail if this file is ever imported into a client component.
 */
export function supabaseAdmin(): SupabaseClient {
  if (cached) return cached;
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error("Supabase is not configured (NEXT_PUBLIC_SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY)");
  cached = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
  return cached;
}

export type SubscriberRow = {
  id: string;
  email: string;
  first_name: string | null;
  created_at: string;
  marketing_consent: boolean;
  consent_timestamp: string | null;
  consent_text_version: string | null;
  consent_source: string | null;
  email_verification_status: "pending" | "verified";
  verified_at: string | null;
  welcome_email_status: "pending" | "sending" | "sent" | "failed" | "skipped";
  welcome_email_sent_at: string | null;
  welcome_email_attempts: number;
  welcome_email_error: string | null;
  notification_status: "pending" | "sending" | "sent" | "failed" | "skipped";
  notification_sent_at: string | null;
  notification_attempts: number;
  notification_error: string | null;
  unsubscribed_at: string | null;
};
