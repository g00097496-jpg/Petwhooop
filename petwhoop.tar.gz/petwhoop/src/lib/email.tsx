import "server-only";
import { Resend } from "resend";
import { render } from "@react-email/render";
import Welcome from "@/emails/Welcome";
import OwnerNotification from "@/emails/OwnerNotification";
import { supabaseAdmin, type SubscriberRow } from "./supabase-admin";
import { manageToken, newVerificationToken, sha256Hex } from "./tokens";
import { siteUrl } from "./site";

type Kind = "welcome" | "notification";

const COLS = {
  welcome: {
    status: "welcome_email_status",
    attempts: "welcome_email_attempts",
    sentAt: "welcome_email_sent_at",
    error: "welcome_email_error",
  },
  notification: {
    status: "notification_status",
    attempts: "notification_attempts",
    sentAt: "notification_sent_at",
    error: "notification_error",
  },
} as const;

const VERIFY_TTL_DAYS = 7;

export function emailConfigured(): boolean {
  return Boolean(process.env.RESEND_API_KEY && process.env.EMAIL_FROM);
}

function shortError(e: unknown): string {
  const msg = e instanceof Error ? e.message : typeof e === "string" ? e : JSON.stringify(e);
  return msg.slice(0, 300);
}

/**
 * Atomically moves a row to "sending". Only one caller can win, so retries and double clicks
 * cannot produce duplicate emails. Returns the row, or null if someone else already has it
 * or it has already been sent.
 */
async function claim(id: string, kind: Kind, extra: Record<string, unknown> = {}): Promise<SubscriberRow | null> {
  const db = supabaseAdmin();
  const col = COLS[kind];
  const { data: current, error: readErr } = await db.from("subscribers").select("*").eq("id", id).maybeSingle();
  if (readErr || !current) return null;
  const row = current as SubscriberRow;

  const { data: won } = await db
    .from("subscribers")
    .update({
      [col.status]: "sending",
      [col.attempts]: (row[col.attempts as keyof SubscriberRow] as number) + 1,
      [col.error]: null,
      ...extra,
    })
    .eq("id", id)
    .in(col.status, ["pending", "failed"])
    .select("id")
    .maybeSingle();

  return won ? row : null;
}

async function finish(id: string, kind: Kind, ok: boolean, error?: string) {
  const col = COLS[kind];
  await supabaseAdmin()
    .from("subscribers")
    .update(
      ok
        ? { [col.status]: "sent", [col.sentAt]: new Date().toISOString(), [col.error]: null }
        : { [col.status]: "failed", [col.error]: error ?? "Unknown error" },
    )
    .eq("id", id);
}

async function deliver(opts: { to: string; subject: string; html: string; text: string; headers?: Record<string, string> }) {
  if (!emailConfigured()) throw new Error("Email provider not configured (RESEND_API_KEY / EMAIL_FROM missing)");
  const resend = new Resend(process.env.RESEND_API_KEY);
  const { error } = await resend.emails.send({
    from: process.env.EMAIL_FROM!,
    to: [opts.to],
    subject: opts.subject,
    html: opts.html,
    text: opts.text,
    headers: opts.headers,
  });
  if (error) throw new Error(`${error.name ?? "ResendError"}: ${error.message}`);
}

/** Sends the branded welcome + email-verification message to the subscriber. */
export async function sendWelcomeEmail(id: string): Promise<"sent" | "failed" | "skipped"> {
  const token = newVerificationToken();
  const expires = new Date(Date.now() + VERIFY_TTL_DAYS * 86_400_000).toISOString();
  const row = await claim(id, "welcome", { verification_token_hash: sha256Hex(token), verification_expires_at: expires });
  if (!row) return "skipped";

  try {
    if (row.unsubscribed_at) {
      await supabaseAdmin().from("subscribers").update({ welcome_email_status: "skipped" }).eq("id", id);
      return "skipped";
    }
    const base = siteUrl();
    const manageUrl = `${base}/unsubscribe?token=${encodeURIComponent(manageToken(id))}`;
    const element = (
      <Welcome
        firstName={row.first_name}
        verifyUrl={`${base}/verify?token=${token}`}
        siteUrl={base}
        manageUrl={manageUrl}
        marketingOptIn={row.marketing_consent}
        heroUrl={`${base}/email/hero.png`}
      />
    );
    const [html, text] = await Promise.all([render(element), render(element, { plainText: true })]);
    await deliver({
      to: row.email,
      subject: "Welcome to the Pack! 🐾 Something Exciting Is Coming.",
      html,
      text,
      headers: {
        "List-Unsubscribe": `<${base}/api/unsubscribe?token=${encodeURIComponent(manageToken(id))}>`,
        "List-Unsubscribe-Post": "List-Unsubscribe=One-Click",
      },
    });
    await finish(id, "welcome", true);
    return "sent";
  } catch (e) {
    await finish(id, "welcome", false, shortError(e));
    return "failed";
  }
}

/** Tells the site owner that someone joined. */
export async function sendOwnerNotification(id: string): Promise<"sent" | "failed" | "skipped"> {
  const row = await claim(id, "notification");
  if (!row) return "skipped";

  try {
    const to = process.env.OWNER_NOTIFY_EMAIL;
    if (!to) throw new Error("OWNER_NOTIFY_EMAIL is not set");
    const element = (
      <OwnerNotification
        firstName={row.first_name}
        email={row.email}
        signedUpAt={row.created_at}
        marketingOptIn={row.marketing_consent}
        adminUrl={`${siteUrl()}/admin`}
      />
    );
    const [html, text] = await Promise.all([render(element), render(element, { plainText: true })]);
    await deliver({ to, subject: "🐾 New PetWhoop Waitlist Signup!", html, text });
    await finish(id, "notification", true);
    return "sent";
  } catch (e) {
    await finish(id, "notification", false, shortError(e));
    return "failed";
  }
}

/** Used right after signup. Errors are recorded on the row, never thrown to the visitor. */
export async function sendSignupEmails(id: string): Promise<void> {
  await Promise.allSettled([sendWelcomeEmail(id), sendOwnerNotification(id)]);
}

/**
 * Admin retry. Rows stuck in "sending" (for example a crashed function) are reset first,
 * then the normal atomic claim runs, so a retry can never double-send a message that succeeded.
 */
export async function retryEmail(id: string, kind: Kind): Promise<"sent" | "failed" | "skipped"> {
  const col = COLS[kind];
  const db = supabaseAdmin();
  await db.from("subscribers").update({ [col.status]: "failed" }).eq("id", id).eq(col.status, "sending");
  return kind === "welcome" ? sendWelcomeEmail(id) : sendOwnerNotification(id);
}
