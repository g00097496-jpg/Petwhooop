import "server-only";
import { supabaseAdmin } from "./supabase-admin";

/**
 * Database-backed rate limiter. Every signup request records the salted IP hash,
 * then we count recent attempts. Works across serverless instances.
 * Returns true when the caller is over the limit.
 */
export async function isRateLimited(ipHash: string): Promise<boolean> {
  const max = Number(process.env.RATE_LIMIT_MAX ?? 5);
  const windowMin = Number(process.env.RATE_LIMIT_WINDOW_MINUTES ?? 10);
  const db = supabaseAdmin();
  const since = new Date(Date.now() - windowMin * 60_000).toISOString();

  const { count, error } = await db
    .from("signup_attempts")
    .select("id", { count: "exact", head: true })
    .eq("ip_hash", ipHash)
    .gte("created_at", since);
  if (error) throw error;

  // Record this attempt whether or not it is allowed, so hammering keeps the counter high.
  await db.from("signup_attempts").insert({ ip_hash: ipHash });

  return (count ?? 0) >= max;
}

/** Verifies a Cloudflare Turnstile token on the server. */
export async function verifyTurnstile(token: string | undefined, ip: string): Promise<boolean> {
  const secretKey = process.env.TURNSTILE_SECRET_KEY;
  if (!secretKey) return false;
  if (!token || token.length > 2048) return false;
  try {
    const body = new URLSearchParams({ secret: secretKey, response: token });
    if (ip && ip !== "unknown") body.set("remoteip", ip);
    const res = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
      method: "POST",
      body,
      signal: AbortSignal.timeout(8000),
    });
    const json = (await res.json()) as { success?: boolean };
    return json.success === true;
  } catch {
    return false;
  }
}
