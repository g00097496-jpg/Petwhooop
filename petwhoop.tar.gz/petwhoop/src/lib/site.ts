/** Public site address without a trailing slash. */
export function siteUrl(): string {
  return (process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000").replace(/\/+$/, "");
}

/** True when the request Origin (if any) belongs to this site. Blocks cross-site form posts. */
export function originAllowed(origin: string | null): boolean {
  if (!origin) return true; // same-origin fetches from some clients omit it; server-side checks still apply
  try {
    const o = new URL(origin);
    const s = new URL(siteUrl());
    if (o.host === s.host) return true;
    if (process.env.NODE_ENV !== "production" && (o.hostname === "localhost" || o.hostname === "127.0.0.1")) return true;
    return false;
  } catch {
    return false;
  }
}

export function clientIp(headers: Headers): string {
  const fwd = headers.get("x-forwarded-for");
  if (fwd) return fwd.split(",")[0]!.trim();
  return headers.get("x-real-ip") ?? "unknown";
}
