/** Shared input rules for the waitlist. Pure functions so they can be unit-tested. */

// Bump this string whenever the wording of the opt-in checkbox changes; it is stored with each consent.
export const CONSENT_TEXT_VERSION = "2026-11-v1";
export const CONSENT_TEXT =
  "Yes, email me PetWhoop launch news, behind-the-scenes updates and early-access invitations. I can unsubscribe at any time.";

const EMAIL_SHAPE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

/** Trim and lower-case. The database stores only this form. */
export function normalizeEmail(raw: unknown): string {
  if (typeof raw !== "string") return "";
  return raw.trim().toLowerCase();
}

export function isValidEmail(email: string): boolean {
  if (email.length < 3 || email.length > 254) return false;
  if (!EMAIL_SHAPE.test(email)) return false;
  const [local, domain] = email.split("@");
  if (!local || !domain || local.length > 64) return false;
  if (domain.startsWith(".") || domain.endsWith(".") || domain.includes("..")) return false;
  return true;
}

/** First name is optional: strip control characters, collapse spaces, cap at 80. Returns null when empty. */
export function cleanFirstName(raw: unknown): string | null {
  if (typeof raw !== "string") return null;
  // eslint-disable-next-line no-control-regex
  const cleaned = raw.replace(/[\u0000-\u001f\u007f<>]/g, "").replace(/\s+/g, " ").trim().slice(0, 80);
  return cleaned.length > 0 ? cleaned : null;
}

/** HTML-escape for the few places user text is placed into HTML we build by hand. */
export function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}
