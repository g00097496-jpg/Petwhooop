import "server-only";
import { supabaseAdmin } from "./supabase-admin";
import { emailHash } from "./tokens";

/** Stops all marketing for this person and records a hashed suppression entry. */
export async function unsubscribeById(id: string): Promise<boolean> {
  const db = supabaseAdmin();
  const { data } = await db.from("subscribers").select("email").eq("id", id).maybeSingle();
  if (!data) return false;
  await db
    .from("suppression_list")
    .upsert({ email_hash: emailHash(data.email as string), reason: "unsubscribed" }, { onConflict: "email_hash" });
  await db
    .from("subscribers")
    .update({ unsubscribed_at: new Date().toISOString(), marketing_consent: false })
    .eq("id", id);
  return true;
}

/** Deletes the subscriber row. A hashed suppression entry is kept so they are never mailed again. */
export async function deleteById(id: string): Promise<boolean> {
  const db = supabaseAdmin();
  const { data } = await db.from("subscribers").select("email").eq("id", id).maybeSingle();
  if (!data) return false;
  await db
    .from("suppression_list")
    .upsert({ email_hash: emailHash(data.email as string), reason: "unsubscribed" }, { onConflict: "email_hash" });
  await db.from("subscribers").delete().eq("id", id);
  return true;
}
