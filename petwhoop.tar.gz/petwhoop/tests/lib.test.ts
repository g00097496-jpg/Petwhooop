import { test } from "node:test";
import assert from "node:assert/strict";
process.env.TOKEN_SECRET = "test-secret-test-secret-test-secret";
process.env.IP_HASH_SALT = "salt";
import { normalizeEmail, isValidEmail, cleanFirstName, escapeHtml } from "../src/lib/validate";
import { manageToken, verifyManageToken, sha256Hex, newVerificationToken } from "../src/lib/tokens";

test("normalizes and validates email", () => {
  assert.equal(normalizeEmail("  Foo@Bar.COM "), "foo@bar.com");
  assert.ok(isValidEmail("a@b.co"));
  assert.ok(!isValidEmail("nope"));
  assert.ok(!isValidEmail("a@b"));
  assert.ok(!isValidEmail("a b@c.com"));
  assert.ok(!isValidEmail("a@b.com\nBcc: x@y.com"));
});
test("first name cleaned", () => {
  assert.equal(cleanFirstName("  Hamda "), "Hamda");
  assert.equal(cleanFirstName(""), null);
  assert.equal(cleanFirstName(12), null);
});
test("escapeHtml", () => assert.equal(escapeHtml("<a>&\""), "&lt;a&gt;&amp;&quot;"));
test("manage token round trip and tamper", () => {
  const id = "11111111-1111-1111-1111-111111111111";
  const t = manageToken(id);
  assert.equal(verifyManageToken(t), id);
  assert.equal(verifyManageToken(t + "x"), null);
  assert.equal(verifyManageToken("abc.def"), null);
  assert.equal(verifyManageToken(null), null);
});
test("verification tokens are random and hashed", () => {
  const a = newVerificationToken(), b = newVerificationToken();
  assert.notEqual(a, b);
  assert.equal(sha256Hex("x").length, 64);
});
