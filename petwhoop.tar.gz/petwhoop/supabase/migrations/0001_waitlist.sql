-- PetWhoop waitlist schema
-- Run in the Supabase SQL editor (Project > SQL Editor > New query), or with the Supabase CLI.
--
-- Security model:
--   * Every table has Row Level Security ENABLED and NO policies, and anon/authenticated
--     privileges are revoked. The browser can never read or write these tables.
--   * All access goes through server code (Next.js route handlers / server components) using
--     the service-role key, which is never sent to the browser.
--   * Admin access is decided server-side against the `admins` table after Supabase Auth login.

-- ---------------------------------------------------------------------------------------
-- subscribers
-- ---------------------------------------------------------------------------------------
create table if not exists public.subscribers (
  id uuid primary key default gen_random_uuid(),

  -- Normalized (trimmed, lower-cased) before insert by the server. Unique.
  email text not null,
  first_name text,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  -- Marketing consent. Never pre-checked. Only true when the person ticked the box.
  marketing_consent boolean not null default false,
  consent_timestamp timestamptz,
  consent_text_version text,
  consent_source text,

  -- Double opt-in. The welcome email carries a one-time verification link.
  email_verification_status text not null default 'pending',
  verification_token_hash text,
  verification_expires_at timestamptz,
  verified_at timestamptz,

  -- Welcome email (sent to the subscriber)
  welcome_email_status text not null default 'pending',
  welcome_email_sent_at timestamptz,
  welcome_email_attempts integer not null default 0,
  welcome_email_error text,

  -- Owner notification email
  notification_status text not null default 'pending',
  notification_sent_at timestamptz,
  notification_attempts integer not null default 0,
  notification_error text,

  -- Unsubscribe. Deleting a person removes the whole row (see suppression_list).
  unsubscribed_at timestamptz,

  -- Abuse handling. Salted hash only, never the raw IP address.
  signup_ip_hash text,

  constraint subscribers_email_len check (char_length(email) between 3 and 254),
  constraint subscribers_email_shape check (email ~ '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  constraint subscribers_email_lower check (email = lower(email)),
  constraint subscribers_name_len check (first_name is null or char_length(first_name) <= 80),
  constraint subscribers_verification_status check (email_verification_status in ('pending', 'verified')),
  constraint subscribers_welcome_status check (welcome_email_status in ('pending', 'sending', 'sent', 'failed', 'skipped')),
  constraint subscribers_notify_status check (notification_status in ('pending', 'sending', 'sent', 'failed', 'skipped')),
  constraint subscribers_consent_record check (
    marketing_consent = false or (consent_timestamp is not null and consent_text_version is not null)
  )
);

create unique index if not exists subscribers_email_key on public.subscribers (email);
create index if not exists subscribers_created_at_idx on public.subscribers (created_at desc);
create index if not exists subscribers_welcome_status_idx on public.subscribers (welcome_email_status);
create index if not exists subscribers_notify_status_idx on public.subscribers (notification_status);

create or replace function public.set_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists subscribers_set_updated_at on public.subscribers;
create trigger subscribers_set_updated_at
  before update on public.subscribers
  for each row execute function public.set_updated_at();

-- ---------------------------------------------------------------------------------------
-- suppression_list: people who must never receive marketing again.
-- Stores only a SHA-256 hash of the normalized email, so it survives a deletion request
-- without keeping the address itself.
-- ---------------------------------------------------------------------------------------
create table if not exists public.suppression_list (
  email_hash text primary key,
  reason text not null default 'unsubscribed',
  created_at timestamptz not null default now(),
  constraint suppression_reason check (reason in ('unsubscribed', 'complaint', 'bounce', 'admin'))
);

-- ---------------------------------------------------------------------------------------
-- signup_attempts: used for database-backed rate limiting (hashed IP + timestamp).
-- ---------------------------------------------------------------------------------------
create table if not exists public.signup_attempts (
  id bigint generated always as identity primary key,
  ip_hash text not null,
  created_at timestamptz not null default now()
);
create index if not exists signup_attempts_ip_time_idx on public.signup_attempts (ip_hash, created_at desc);

-- Data retention: keep attempts for 7 days only. Schedule with pg_cron, or run by hand.
create or replace function public.purge_old_signup_attempts() returns void
language sql as $$
  delete from public.signup_attempts where created_at < now() - interval '7 days';
$$;

-- ---------------------------------------------------------------------------------------
-- admins: who may open /admin. Add a row after you create the user in Supabase Auth.
-- ---------------------------------------------------------------------------------------
create table if not exists public.admins (
  user_id uuid primary key references auth.users (id) on delete cascade,
  email text not null,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------------------------
-- campaigns: PREPARED for future announcements. Nothing in the app sends campaigns yet.
-- A campaign must be explicitly approved by an admin before any sending feature can use it.
-- ---------------------------------------------------------------------------------------
create table if not exists public.campaigns (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  subject text not null,
  status text not null default 'draft',
  approved_by uuid references auth.users (id),
  approved_at timestamptz,
  created_at timestamptz not null default now(),
  constraint campaigns_status check (status in ('draft', 'approved', 'sending', 'sent', 'cancelled')),
  constraint campaigns_approved_consistent check (status = 'draft' or approved_at is not null)
);

create table if not exists public.campaign_recipients (
  campaign_id uuid not null references public.campaigns (id) on delete cascade,
  subscriber_id uuid not null references public.subscribers (id) on delete cascade,
  status text not null default 'queued',
  sent_at timestamptz,
  error text,
  primary key (campaign_id, subscriber_id),
  constraint campaign_recipient_status check (status in ('queued', 'sent', 'failed', 'skipped'))
);

-- The ONLY audience a marketing campaign may use: explicit consent, verified address,
-- not unsubscribed, not suppressed.
create or replace view public.marketing_eligible
with (security_invoker = true) as
select s.*
from public.subscribers s
where s.marketing_consent = true
  and s.email_verification_status = 'verified'
  and s.unsubscribed_at is null
  and not exists (
    select 1 from public.suppression_list x
    where x.email_hash = encode(sha256(convert_to(s.email, 'UTF8')), 'hex')
  );

-- ---------------------------------------------------------------------------------------
-- Row Level Security: enabled everywhere, no policies = no access for anon/authenticated.
-- The service-role key (server only) bypasses RLS.
-- ---------------------------------------------------------------------------------------
alter table public.subscribers enable row level security;
alter table public.suppression_list enable row level security;
alter table public.signup_attempts enable row level security;
alter table public.admins enable row level security;
alter table public.campaigns enable row level security;
alter table public.campaign_recipients enable row level security;

revoke all on public.subscribers from anon, authenticated;
revoke all on public.suppression_list from anon, authenticated;
revoke all on public.signup_attempts from anon, authenticated;
revoke all on public.admins from anon, authenticated;
revoke all on public.campaigns from anon, authenticated;
revoke all on public.campaign_recipients from anon, authenticated;
revoke all on public.marketing_eligible from anon, authenticated;
revoke all on function public.purge_old_signup_attempts() from anon, authenticated, public;
revoke all on function public.set_updated_at() from anon, authenticated, public;
